<?php
/**
 * @version    1.0.0
 * @since      2013-07-08
 * @author     Argoworks
 * @descriptions ...
 * @copyright  Copyright &copy; 2013 Argoworks, http://www.argoworks.com
 * @package    ...
*/
class DefaultController extends CController
{
	public function actionIndex(){

	}
}