<?php 
return
	array(
		'controllerMap' => array(
			'search' => array(
				'class' => 'custom.controllers.ArgoworksSearchController',
			),
		),	
);				
