<?php
/**
 * @version    1.0.0
 * @since      2013-07-08
 * @author     Argoworks team
 * @descriptions ...
 * @copyright  Copyright &copy; 2013 Argoworks, http://www.argoworks.com
 * @package    ...
*/
?>
<?php
class DefaultController extends CController
{
	public function actionIndex(){

	}
	public function actionGetmatrixproduct()
	{
		if(Yii::app()->request->isAjaxRequest) {

			$id = Yii::app()->getRequest()->getParam('id');
			$strSize= Yii::app()->getRequest()->getParam('product_size');
			$strColor= Yii::app()->getRequest()->getParam('product_color');

			$objProduct = Product::LoadChildProduct($id, $strSize, $strColor);


			if ($objProduct instanceof Product)
			{
				$arrReturn['status'] = 'success';
				$arrReturn['id'] = $objProduct->id;
				$arrReturn['FormattedPrice'] = $objProduct->Price;
				$arrReturn['FormattedRegularPrice'] = $objProduct->SlashedPrice;
				$arrReturn['image_id'] = CHtml::image(Images::GetLink($objProduct->image_id, ImagesType::pdetail));
				$arrReturn['code'] = $objProduct->code;
				$arrReturn['title'] = $objProduct->Title;
				$arrReturn['InventoryDisplay'] = $objProduct->InventoryDisplay;

				if ($objProduct->WebLongDescription)
					$arrReturn['description_long'] = $objProduct->WebLongDescription;
				else
					$arrReturn['description_long'] = $objProduct->parent0->WebLongDescription;

				if ($objProduct->description_short)
					$arrReturn['description_short'] = $objProduct->WebShortDescription;
				else
					$arrReturn['description_short'] = $objProduct->parent0->WebShortDescription;
			}
			else
			{
				// options are missing so return the master product

				$objProduct = Product::model()->findByPk($id);

				$arrReturn['FormattedPrice'] = $objProduct->Price;
				$arrReturn['code'] = $objProduct->code;
				$arrReturn['title'] = $objProduct->Title;
				$arrReturn['InventoryDisplay'] = $objProduct->InventoryDisplay;
				if ($objProduct->WebLongDescription)
					$arrReturn['description_long'] = $objProduct->WebLongDescription;
				if ($objProduct->description_short)
					$arrReturn['description_short'] = $objProduct->WebShortDescription;

			}
		
			Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			$arrReturn['photos'] = $this->renderPartial('application.views-cities.product._photosmagic', array('model'=>$objProduct,'FkParentID'=>$id,), true,false);
			echo json_encode($arrReturn);
		}

	}
}