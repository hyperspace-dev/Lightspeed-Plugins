<?php
return array(
    '1#Add files|0#Choose file' => '1#Добавить файлы|0#Выбрать файл',
    'File is too big' => 'Файл слишком большой',
    'File is too small' => 'Файл слишком маленький',
    'Filetype not allowed' => 'Запрещённый тип файла',
    'Max number of files exceeded' => 'Превышено максимальное количество файлов',
    'Uploaded bytes exceed file size' => 'Загружено больше байт, чем размер файла',
    'Empty file upload result' => 'Пустой файл',
    "Error" => 'Ошибка',
    "Start" => 'Загрузить',
    "Cancel" => 'Отменить',
    "Delete" => 'Удалить'

);