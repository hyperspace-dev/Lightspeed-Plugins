<?php

//For extending checkout model if necessary

class Argoworks extends CActiveRecord
{
	public function tableName()
    {
        return 'xlsws_argoworks';
    }
	
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	
	public static function CheckSetDb(){
		$q=Yii::app()->db->createCommand()->from('xlsws_configuration')->where('key_name=:key_name', array(':key_name'=>'versionargoworks'))->queryRow();
		return $q;	
	}
	
	public static function SetDb()
	{
	
		try{
			Yii::app()->db->createCommand()->createTable('xlsws_argoworks', array('id'=>'pk', 'name'=>'string NOT NULL', 'router'=>'string NOT NULL', 'version'=>'string NOT NULL', 'author'=>'string NOT NULL', 'author_url'=>'string NOT NULL', 'plugin_url'=>'string NOT NULL', 'description'=>'string NOT NULL', 'active'=>'integer NOT NULL', 'license'=>'string NOT NULL', 'active_license'=>'string NOT NULL',));
			Yii::app()->db->createCommand()->createTable('xlsws_argoworks_notifications', array('id'=>'pk', 'name'=>'string NOT NULL', 'version'=>'string NULL', 'author'=>'string NULL', 'datecreate'=>'datetime NULL', 'datemodify'=>'datetime NULL', 'router'=>'string NULL', 'message'=>'string NULL', 'message_type'=>'string NOT NULL', 'update_link'=>'string NULL', 'external_link'=>'string NULL', 'description'=>'string NULL', 'readed'=>'string NULL',));
			$arrPattern=array('title','key_name','key_value','helper_text','configuration_type_id','sort_order','modified','created','options','template_specific','param','required',);		
			$arrVersionArgoworks=array('Version','versionargoworks','1.0.0','what is help',83,1,'2013-06-06 12:52:39','2013-05-06 00:00:00','NULL',0,1,1,);		
			$arrCVersionArgoworks=array_combine($arrPattern,$arrVersionArgoworks);
			$insert = Yii::app()->db->createCommand()->insert('xlsws_configuration',$arrCVersionArgoworks);
		}
		catch(exception $e)
		{
			Yii::app()->user->setFlash('error',Yii::t('admin','Create database error. Database can existed.'));
		   return false;
		}
	}
	
	public function Checkversion($id,$version)
	{
	
		$models = Yii::app()->db->createCommand()
			->select('key_value')
			->from('xlsws_configuration')
			->where('configuration_type_id=:configuration_type_id', array(':configuration_type_id'=>$id))
			->queryAll();
		if(!$models) return false; // Check valid config
			if(str_replace('.','',$version)>str_replace('.','',$models[0]["key_value"])){
				
				return false;
			}
		return true;
	}
	
	protected function _prepareUpdateData($data){
		$data_need_insert = array(
			'name'=>'',
			'version'=>'',
			'author'=>'',
			'router'=>'',
			'message'=>'',
			'message_type'=>'',
			'update_link'=>'',
			'external_link'=>'',
			'description'=>'',
			'readed'=>''
		);
		foreach($data_need_insert as $key=>$val){
			if(isset($data[$key])){
				$data_need_insert[$key] = $data[$key];
			}
		}
		return $data_need_insert;
	}
	
	public function GetDataServer()
	{
		$server_url = "http://www.argoworks.com/feeds-plugins";
		
		$objCurl = curl_init();
		$timeout = 10;
		curl_setopt ($objCurl, CURLOPT_URL, $server_url);
		curl_setopt ($objCurl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($objCurl, CURLOPT_CONNECTTIMEOUT, $timeout);
		
		$result = curl_exec($objCurl);
		$return_code = curl_getinfo($objCurl, CURLINFO_HTTP_CODE); // Get status code of server
		curl_close($objCurl);
		$listReponseResult = json_decode($result,true);
		
		if(!is_array($listReponseResult)) return ;
		
		if($return_code<200 || $return_code>300 || !is_array($listReponseResult)) return array(); // Check valid data from server.
		
		foreach($listReponseResult as $key=>$item)
		{	
			$is_inserted = Yii::app()->db->createCommand()->where('name=:name',array(':name'=>$item['name']))->from('xlsws_argoworks_notifications')->queryRow();
			$data_update = $this->_prepareUpdateData($item);
			if(!$is_inserted){
				Yii::app()->db->createCommand()->insert('xlsws_argoworks_notifications',$data_update);
			}else{
				
				Yii::app()->db->createCommand()->update('xlsws_argoworks_notifications',$data_update,'id=:id',array(':id'=>$is_inserted['id']));
			}
		}
		
		return $listReponseResult;
	}
	
	public function getVersion($plugin_name){
		
		$result = Yii::app()->db->createCommand()
					->from('xlsws_argoworks')
					->where('name=:name',array(':name'=>$plugin_name))
					->queryRow();
		
		if($result){
			return $result['version'];
			
		}
		
	}
	
	public function Checkupdate($current_version,$plugin_name)
	{
		$dataUpdate = Yii::app()->db->createCommand()
			->where('router=:router AND message_type=:message_type',array(':router'=>trim($plugin_name),':message_type'=>'plugin_update'))
			->order('id DESC')
			->from('xlsws_argoworks_notifications')->queryRow();
		$arrResult['alert']="";
		
		if(!empty($dataUpdate) && (str_replace('.','',$dataUpdate['version'])>str_replace('.','',$current_version))){

			$arrResult['status']  = false;
			$arrResult['version'] = $dataUpdate['version'];
			$arrResult['source']  = $dataUpdate['update_link'];
			return $arrResult;
		}
		
		$arrResult['status']  = true;
		$arrResult['version'] = $current_version;
		$arrResult['source']  = "";

		return $arrResult;
	}
	public function createMenuArgo($SelfmenuItems,$InfoRouter)
	{
		/* Create menu*/
		$menuItems =array();
		$activePlugins = $this->getListActivePlugin();
		
		if(count($activePlugins)>0){
			$menuItems[] = array('label'=>'Argoworks Plugins');
			foreach($activePlugins as $_plugin){
					if($InfoRouter==$_plugin->router){
						$menuItems[] = array(
							'label'=>$_plugin->name,
							'url' =>array($_plugin->router.'/index')
						);
						foreach($SelfmenuItems as $itemM){
							$menuItems[]= $itemM;
						}
					}else{
						$menuItems[] = array(
							'label'=>$_plugin->name,
							'url' =>array($_plugin->router.'/index')		
						);
					}
			}
		}
		
		/* Create amount module need update*/
		$needUpdate = 0;
		$criteria = new CDbCriteria();
		$objPlug  = Argoworks::model()->findAll($criteria);
		
		foreach($objPlug as $item){
			
			$update = Argoworks::model()->Checkupdate($item->version,$item->name);
			
			if(!$update['status']){
				$needUpdate++;
			}
		}
		
		if($needUpdate==0){
			$needUpdate="";
		}else{
			$needUpdate='('.$needUpdate.' update available)';
		}
		$menuItems =array_merge($menuItems,
			array(
					array('label'=>'Manage Plugins'),
						array('label'=>'Plugin Manager'.$needUpdate, 'url'=>array('argoworks/plugin')),
						array('label'=>'Upload Plugin', 'url'=>array('argoworks/upload'))
						
			)
		);
		
		return $menuItems;
	}
	
	public function checkLicense($InfoRouter)
	{
		$criteria=new CDbCriteria();
		$criteria->addCondition('router="'.$InfoRouter.'"');
		$objPlugR=Argoworks::model()->findAll($criteria);
		foreach($objPlugR as $item){
		$active_license=md5(substr(md5($item->license),1,5).substr(md5($_SERVER['SERVER_NAME']),8,15));
		$active_license_www = md5(substr(md5($item->license),1,5).substr(md5('www.'.$_SERVER['SERVER_NAME']),8,15));
			if($active_license==$item->active_license || $active_license_www == $item->active_license){
				return true;
			}else{
				return false;
			}
		}
		
	}
	
	public function insertChildModule($plugin_info){
		$plugin_data = array(
				'name'=>$plugin_info['name'],
				'router'=>$plugin_info['router'],
				'version'=>$plugin_info['version'],
				'author'=>$plugin_info['author'],
				'author_url'=>$plugin_info['author_url'],
				'plugin_url'=>$plugin_info['plugin_url'],
				'description'=>$plugin_info['description'],
				'active'=>0,
				'license'=>'',
				'active_license'=>'',
		);
		Yii::app()->db->createCommand()->insert('xlsws_argoworks',$plugin_data);
	}
	
	public function updateChildModule($plugin_info){
		$plugin_data = array(
				'name'=>$plugin_info['name'],
				'router'=>$plugin_info['router'],
				'version'=>$plugin_info['version'],
				'author'=>$plugin_info['author'],
				'author_url'=>$plugin_info['author_url'],
				'plugin_url'=>$plugin_info['plugin_url'],
				'description'=>$plugin_info['description']
		);
		Yii::app()->db->createCommand()->update('xlsws_argoworks',$plugin_data,'router=:router',array(':router'=>$plugin_info['router']));
	}
	
	public function updatePlugin($module,$action)
	{
		if($action=='active'){
			Yii::app()->db->createCommand()->update('xlsws_argoworks',array('active'=>1),'id='.$module);
		}
		if($action=='deactive'){
			Yii::app()->db->createCommand()->update('xlsws_argoworks',array('active'=>0),'id='.$module);
		}
	}	
	
	public function getListActivePlugin()
	{
		$criteria=new CDbCriteria();
		$criteria->addCondition('active=1');
		$models=$this->findAll($criteria);
		return $models;
	}	
	
	public function getListRouterPlugin()
	{
		$criteria=new CDbCriteria();
		$models=$this->findAll($criteria);
		$arrRouter=array();
		foreach($models as $item){
			$arrRouter[]=$item->router;
		}
		return $arrRouter;
	}
}
