$(document).ready(function(){
	$('.navbar-inner ul.nav li').each(function(){
		if($(this).children('a').text()==""){
			$(this).css('display','none');
		}
	});
});