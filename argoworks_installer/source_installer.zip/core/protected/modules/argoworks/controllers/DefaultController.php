<?php
class DefaultController extends CController
{

}