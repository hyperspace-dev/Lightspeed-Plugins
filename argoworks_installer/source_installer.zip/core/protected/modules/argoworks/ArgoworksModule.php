<?php
class ArgoworksModule extends CWebModule
{
	public function init()
	{
	$this->setImport(array(
		'argoworks.models.*',
		'argoworks.components.*',
	));
	}
}