<?php
/**
 * @version    1.0.0
 * @since      2013-07-05
 * @author     Argoworks Team
 * @copyright  Copyright &copy; 2013 Argoworks, http://www.argoworks.com
 * @package    Argoworks
*/
class ArgoworksController extends AdminBaseController{
/*-------------------------------------Global-------------------------------------------*/
	const CURRENT_VERSION= '1.0.0';
	const SETTING= 81;
	const VER= 83;
	const URL_LICENSE= 'http://www.argoworks.com/';
	public $controllerName = "Argoworks Plugins";
	public function actions()
	{
		return array(
			'edit'=>'admin.edit',
		);
	}
	public function accessRules()
	{
		return array(
				array('allow',
						'actions'=>array('index','install','config','plugin','upload','update','Exportmod','Removemod','Exportallmod','license','system'),
						'roles'=>array('admin'),
				),
		);
	}	
	public function beforeAction($action)
	{
		date_default_timezone_set(_xls_get_conf('TIMEZONE'));
		if(Argoworks::CheckSetDb()===false){
			Argoworks::SetDb();
		}else{
			Argoworks::model()->Checkversion(self::VER,self::CURRENT_VERSION);
		}
		$this->menuItems =Argoworks::model()->createMenuArgo(null,null);

		return parent::beforeAction($action);
	}
	public function actionExportmod()
	{
		if (!file_exists(Yii::getPathOfAlias('webroot').'/argoworks')) {
			mkdir(Yii::getPathOfAlias('webroot').'/argoworks');
		}
		$namedir='/argoworks/'.$_REQUEST['router'].' '.date("h i d m");
		mkdir(Yii::getPathOfAlias('webroot').$namedir);
		foreach(array('argoworks') as $itemM){
			$config = new DOMDocument();
			$config->load( Yii::getPathOfAlias('webroot').'/core/protected/modules/'.$itemM.'/config.xml' );
			$folder = $config->getElementsByTagName("Folder");
			$arrFolder=$folder->item(0);
			$arrFolder=$arrFolder->getElementsByTagName("Path");
			foreach( $arrFolder as $item )
			{
				if (!file_exists(Yii::getPathOfAlias('webroot').$namedir.$item->nodeValue)) {
					mkdir(Yii::getPathOfAlias('webroot').$namedir.$item->nodeValue);
				}
			}
			$file = $config->getElementsByTagName("File");
			$arrFile=$file->item(0);
			$arrFile=$arrFile->getElementsByTagName("Name");
			foreach( $arrFile as $item )
			{
				$file=Yii::getPathOfAlias('webroot').$item->nodeValue;
				$path=Yii::getPathOfAlias('webroot').$namedir.$item->nodeValue;
				copy($file,$path);
			}
		}
		$this->redirect($this->createUrl('argoworks/plugin'));
	}	

	public function actionRemovemod()
	{
		$config = new DOMDocument();
		
		if(!file_exists(Yii::getPathOfAlias('webroot').'/core/protected/modules/'.$_REQUEST['router'].'/config.xml')){
			
			Header( "Location: ".Yii::app()->getBaseUrl(true)."/admin/argoworks/plugin" );
		}
		$config->load( Yii::getPathOfAlias('webroot').'/core/protected/modules/'.$_REQUEST['router'].'/config.xml' );
		$database = $config->getElementsByTagName("Database")->item(0); // Get Xml Database
		$arrTable=$database->getElementsByTagName("Table")->item(0);
		$arrTable=$arrTable->getElementsByTagName("Name");
		foreach( $arrTable as $item )
		{
			try{ 
				$delTab = Yii::app()->db->createCommand()->dropTable($item->nodeValue);
			}catch(exception $e){}	
		}
		
		$arrRow=$database->getElementsByTagName("Row");
		foreach( $arrRow as $item )
		{
			$delRow = Yii::app()->db->createCommand()->delete($item->getElementsByTagName("From")->item(0)->nodeValue, $item->getElementsByTagName("Key")->item(0)->nodeValue.'='.$item->getElementsByTagName("Value")->item(0)->nodeValue);
		}
		try{  
			$delRow = Yii::app()->db->createCommand()->delete('xlsws_argoworks', 'router="'.$_REQUEST['router'].'"'); //Delete from table argowork
		}catch(exception $e){}
		// Remove folder of plugins
		$file = $config->getElementsByTagName("File"); 
		$arrFile=$file->item(0);
		$arrFile=$arrFile->getElementsByTagName("Name");
		foreach( $arrFile as $item )
		{
			$file=Yii::getPathOfAlias('webroot').$item->nodeValue;
			if(file_exists($file)){
				try{ 
					@unlink($file);
				}catch(exception $e){}
			}	
		}
		// Remove folder of plugins
		$folder = $config->getElementsByTagName("Folder");
		$arrFolder=$folder->item(0);
		$arrFolder=$arrFolder->getElementsByTagName("Path");
		foreach( $arrFolder as $item )
		{
			if (file_exists(Yii::getPathOfAlias('webroot').$namedir.$item->nodeValue)) {
				@rmdir(Yii::getPathOfAlias('webroot').$item->nodeValue);
			}
		}		
		Header( "Location: ".Yii::app()->getBaseUrl(true)."/admin/argoworks/plugin" );
	}

	public function checkPlugins(){
		
		$arrRouter=Argoworks::model()->getListRouterPlugin();
		foreach($this->getArgoControllerList() as $itemC){
			if(!in_array($itemC['router'],$arrRouter)){
				Argoworks::model()->insertChildModule($itemC);
			}else{
				Argoworks::model()->updateChildModule($itemC);
				
			}
		}		
	}
	public function actionIndex()
	{
		$arrServer=Argoworks::model()->GetDataServer(); // Check notifications when visit page index
		$arrNotifications = Yii::app()->db->createCommand()
			->where('message_type=:message_type',array(':message_type'=>'message'))
			->order('id DESC')
			->from('xlsws_argoworks_notifications')->queryRow();
		$this->checkPlugins();
		$this->render('index',array('notifi'=>$arrNotifications));
	}
	public function actionLicense(){
		$router=$_REQUEST['router'];
		$criteria=new CDbCriteria();
		$criteria->addCondition('router="'.$router.'"');
		$objPlugR=Argoworks::model()->findAll($criteria);
		$pluginInfo = Argoworks::model()->find($criteria);
		$plugin_name = $pluginInfo->name ;
		if(isset($_POST['submit'])){
			$requestUrl = self::URL_LICENSE.'?edd_action=activate_license&license='.$_POST['license'].'&item_name='.str_replace(' ','%20',$plugin_name);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $requestUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$response = curl_exec($ch);
			curl_close($ch);
			$arrLicense=json_decode($response,true);
			if($arrLicense['license']=='valid'){
				$active_license=md5(substr(md5($_POST['license']),1,5).substr(md5($_SERVER['SERVER_NAME']),8,15));
				Yii::app()->db->createCommand()
							->update('xlsws_argoworks',
							array('license'=>$_POST['license'],'active_license'=>$active_license),'router="'.$router.'"');
				Yii::app()->user->setFlash('success',Yii::t('admin','The module is activated succesfully. Thank for using argoworks plugins.'));
				$objPlugR=Argoworks::model()->findAll($criteria);
			}else{
				Yii::app()->user->setFlash('error',Yii::t('admin','Your licence is invalid. Please make a purchase to use this module or contact with argoworks.'));
			}
		}
		$this->render('license',array('Info'=>$objPlugR));
		
	}
	
	public function actionPlugin()
	{
		if(isset($_GET['module']) && isset($_GET['action']))
		{
			$update=Argoworks::model()->updatePlugin($_GET['module'],$_GET['action']);	
			$this->redirect($this->createUrl('argoworks/plugin'));
		}
		$numberofpage=10; 
		$numberlink=3; 
		$curpage=1;
		if(isset($_REQUEST['page'])){
			$curpage=$_REQUEST['page']; 
		}
		$this->checkPlugins();
		$criteria=new CDbCriteria();
		$numberOfRecords=Argoworks::model()->count($criteria);
		$pages = new CPagination($numberOfRecords);
		$pages->setPageSize($numberofpage);
		$pages -> applyLimit($criteria);
		$models= Argoworks::model() -> findAll($criteria);
		$this->render("plugin", array(
								'plugins' => $models,
								'itemCount'=>$numberOfRecords,
								'numberreviewofpage'=>$numberofpage,
								'numberlink'=>$numberlink,
								'page'=>$curpage-1,
		)
		);
	}
	
	protected function getFile($url)
	{
		//$url = "http://cdn.lightspeedretail.com/webstore/webstore-incremental/".$url;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);

		// Turn off the server and peer verification (TrustManager Concept).
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$resp = curl_exec($ch);
		curl_close($ch);
		return $resp;


	}

	protected function unzipFile($path,$file)
	{
		require_once( YiiBase::getPathOfAlias('application.components'). '/zip.php');

		extractZip($file,'',$path);

		return true;
	}

	protected function actionDownload($url,$router)
	{

		//regex filename to make sure we're not passing something wrong

		$d = YiiBase::getPathOfAlias('webroot');
		@mkdir($d,0777,true);
		@unlink($d."/".$router.".zip");
		$data = $this->getFile($url);
		$f=file_put_contents($d."/".$router.".zip", $data);

		if ($f)
		{
			$blnExtract = $this->unzipFile(YiiBase::getPathOfAlias('webroot'),$router.".zip");
			if($blnExtract)
			{
				//@unlink($d."/".$router.".zip");
				return true;
			}else{
				return false;
			}
		}

	}
	
	public function actionUpdate()
	{
		$product = $_REQUEST['plugin'];
		$version = Argoworks::model()->getVersion($product);
		$plugin = Argoworks::model()->Checkupdate($version,$product); 
		if(!empty($plugin) && $plugin['source'] !=''){
			
			$downloaded = $this->actionDownload($plugin['source'],'plugin_upgrade') ;
			
			if ($downloaded) {
				$status= 'The plugin is upgraded succesfully.<br/>';
			} else {
				$status= 'Have a problem occurs on upgrading this plugin<br/>';
			}
		}
		$this->checkPlugins();
		$this->render('update',array('status'=>$status));
	}

	protected function getArgoControllerList()
	{
		$arrControllerList = array();
		$declaredClasses = get_declared_classes();
		foreach (glob(Yii::getPathOfAlias('admin.controllers') . "/*Controller.php") as $controller){
			$class = basename($controller, ".php");
			if (!in_array($class, $declaredClasses)) {
				Yii::import("admin.controllers." . $class, true);
			}
			$arrControllerList[] = $class;
		}
		$arrItem=array();
		foreach ($arrControllerList as $key=>$val)
		{
			$cControl = new $val('default');
			if(isset($cControl->InfoModule)){
				$arrItem[]=$cControl->InfoModule;
			}
		}
		return $arrItem;
	}
	
	public function actionUpload(){
		if (isset($_POST['yt0']))
		{
				if($_FILES['plugin_file']["tmp_name"]){
				$zip = new ZipArchive;
					if ($zip->open($_FILES['plugin_file']["tmp_name"]) === TRUE) {
						$zip->extractTo('./');
						$zip->close();
						$status= 'The plugin is installed succesfully<br/>';
					} else {
						$status= 'Opp! Have some problems occur on installing the plugin. Please try again.<br/>';
					}
				}
			$this->redirect($this->createUrl('argoworks/plugin'));
		}
		$this->render("upload")	;
	
	}
}
