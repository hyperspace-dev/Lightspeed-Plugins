<?php
/**
 * @version    1.0.0
 * @since      2013-07-05
 * @author     Argoworks Team
 * @copyright  Copyright &copy; 2013 Argoworks, http://www.argoworks.com
 * @package    Argoworks
*/
class ArgoblankController extends AdminBaseController{
	public $controllerName = "";
	public function __construct()
	{
		
		$data = $this->GetDataServer();
		$version = str_replace(".","",XLSWS_VERSION) ;
		$version = (int)$version ;
		
		if(!empty($data)){
			$message = $data[0]['message'] ;
			if($version >307){
				Yii::app()->clientScript->registerScript('notification','
					$(document).ready(function(){
						$(\'<div class="container-fluid notification" style="margin-top:20px"><div class="row-fluid"><div class="span3"></div><div class="span9"><div class="notification-msg" style="margin-bottom:0px">'.addslashes($message).'</div></div></div></div>\').insertAfter(".navbar");
					});
				');
			}else{
				Yii::app()->clientScript->registerScript('notification','
					$(document).ready(function(){
						$(\'<div class="container-fluid notification" ><div class="row-fluid"><div class="span3"></div><div class="span9"><div class="notification-msg">'.addslashes($message).'</div></div></div></div>\').insertAfter(".navbar");
					});
				');
			
			}
 			
		}
		$url=Yii::app()->getRequest()->getBaseUrl().'/css/argoworks/css/style.css';
		Yii::app()->clientScript->registerCssFile($url);		
		Yii::app()->clientScript->registerScriptFile(Yii::app()->getRequest()->getBaseUrl().'/css/argoworks/css/'.'script.js');
	}
	
	public function GetDataServer()
	{
		$server_url = "http://www.argoworks.com/feeds-plugins";
		
		$objCurl = curl_init();
		$timeout = 10;
		curl_setopt ($objCurl, CURLOPT_URL, $server_url);
		curl_setopt ($objCurl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($objCurl, CURLOPT_CONNECTTIMEOUT, $timeout);
		
		$result = curl_exec($objCurl);
		$return_code = curl_getinfo($objCurl, CURLINFO_HTTP_CODE); // Get status code of server
		curl_close($objCurl);
		$listReponseResult = json_decode($result,true);
		
		if(!is_array($listReponseResult)) return array() ;
		
		if($return_code<200 || $return_code>300 || !is_array($listReponseResult)) return array(); // Check valid data from server.
		
		return $listReponseResult;
	}	
}

