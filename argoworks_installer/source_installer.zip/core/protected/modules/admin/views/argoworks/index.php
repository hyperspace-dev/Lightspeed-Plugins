<div class="span9">
    <div class="argoworks-head">
        <h1 class="title">LightSpeed eCommerce Plugins</h1>
        <p><strong>The installer enables LightSpeed eCommerce users to easily download, install and update new plugins for LightSpeed eCommerce.</strong></p>
		<h3>Summary</h3>
        <p>The installer enables LightSpeed eCommerce users to easily download new plugins for LightSpeed eCommerce. It provides the ability to install new feature functionality into your LightSpeed eCommerce web site automatically through the LightSpeed eCommerce admin panel.
			For additional information about this installer or to see our entire selection of plugins, <a href="http://www.argoworks.com/downloads/category/lightspeed-ecommerce-3-0-plugins" target="_blank">click here.</a></p>		<h3>Support:</h3>
		<p>
		If you have a plugin issue and need service, please contact Argoworks at <a target="_blank" href="http://www.argoworks.com/helpsupport">argoworks.com</a> for plugin support
		</p>
	</div>
</div><!--/span-->