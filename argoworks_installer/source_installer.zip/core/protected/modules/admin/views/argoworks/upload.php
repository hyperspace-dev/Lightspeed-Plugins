<div class="span9">	<div class="hero-unit">		<h3><?php echo Yii::t('admin','Upload Plugin'); ?></h3>
		<div class="editinstructions">			<?php echo Yii::t('admin','This form allows you to upload a .zip file plugin developed by Argoworks. This process will automatically extract and install this plugin to system.'); ?>		</div>			<?php echo CHtml::beginForm('upload', 'post', array('enctype'=>'multipart/form-data')); ?>			<div class="row">				<div class="span5"><?php echo CHtml::label(Yii::t('admin','Choose your plugin .zip file (Max size: {max}):',array('{max}'=>ini_get('upload_max_filesize'))), 'plugin_file'); ?></div>				<div class="span5"><?php echo CHtml::fileField('plugin_file', '', array('id'=>'plugin_file')); ?></div>			</div>			<p class="pull-right">
				<?php $this->widget('bootstrap.widgets.TbButton', array(
					'buttonType'=>'submit',
					'label'=>'Upload',
					'type'=>'primary',
					'size'=>'large',
				)); ?>
			</p>			<?php echo CHtml::endForm(); ?>
		</div>
	</div>
</div>