<div class="span9">
	<h4><?php echo Yii::t('admin','Update Plugin'); ?></h4>
	<p><?php echo $status; ?></p>
</div>