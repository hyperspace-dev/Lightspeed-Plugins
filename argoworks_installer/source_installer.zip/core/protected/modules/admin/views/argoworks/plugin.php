<div class="span9">
	<div class="hero-unit">
		<h3><?php echo Yii::t('admin','Manage Plugins'); ?></h3>
		<?php if(count($plugins)>0): ?>
		<div class="editinstructions">
			<div class="grid-view" id="user-grid">
				<table class="table-bordered table">
					<tr>
						<th id="user-grid_c1" style="span1"><?php echo Yii::t('admin','Plugin'); ?></th>
						<th id="user-grid_c1" style="span1"><?php echo Yii::t('admin','Description'); ?></th>
					</tr>
					<?php foreach($plugins as $_plugin): ?>
					<tr>
						<td>
						<?php echo $_plugin['name']; ?><br/>
						<div class="action">
						<?php if(!$_plugin['active']): ?>							<a href="<?php echo $this->createUrl("argoworks/plugin"); ?>?module=<?php echo $_plugin['id']; ?>&action=active" ><?php echo Yii::t('admin','Activate'); ?></a>						<?php else: ?>							<a href="<?php echo $this->createUrl("argoworks/plugin"); ?>?module=<?php echo $_plugin['id']; ?>&action=deactive"><?php echo Yii::t('admin','Deactivate'); ?></a>						<?php endif ; ?>
						<span> | </span>
						<a href="#" onClick="VerifyRemove('<?php echo $this->createUrl("removemod?router=".$_plugin['router']); ?>')"><?php echo Yii::t('admin','Remove'); ?></a>

						</div>
						</td>
						<td>
						<?php echo $_plugin['description']; ?><br/>
						<?php echo Yii::t('admin','Version'); ?> : <?php echo $_plugin['version']; ?> | <?php echo Yii::t('admin','By'); ?> <a target="_blank" href="<?php echo $_plugin['author_url']; ?>" title="<?php echo $_plugin['author']; ?>"><?php echo $_plugin['author']; ?></a>						<div class="update-msg">
							<?php 
							$update=Argoworks::model()->Checkupdate($_plugin->version,$_plugin['name']); 
							if(!empty($update) && !$update['status']): ?>
								<span><i>There is a new version <?php echo $update['version']; ?> of <?php echo $_plugin['name']; ?> available.</i></span></span><a href="update?plugin=<?php echo $_plugin['name']; ?>" >Update now.</a>
							<?php endif; ?>						
						</div>
						</td>					</tr>
					<?php endforeach ; ?>
				</table>
			</div>
		</div>
		<?php else: ?>
		<div class="editinstructions">
			<?php echo Yii::t('admin','There is no plugin in your system.'); ?>
		</div>
		<?php endif; ?>
	</div>
</div>
<script>
	function VerifyRemove(link){
		if (confirm('<?php echo Yii::t('admin','Are you sure you want to remove this module ?'); ?>')) {
			window.location = link;
		} else {
			// Do nothing!
		}
	}
</script>