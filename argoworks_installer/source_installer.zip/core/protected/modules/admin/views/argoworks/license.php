<div class="span9">
	<?php if(Argoworks::model()->checkLicense($_REQUEST['router'])): ?>
	<div class="hero-unit">
			<?php foreach($Info as $item): ?>
				<h4>Module <?php echo  $item->name;?> is activated</h4>
				<p>License: <?php echo  $item->license;?></p>
			<?php endforeach; ?>
	</div>
	<?php else: ?>
	<div class="hero-unit">
		<?php echo CHtml::beginForm('license?router='.$_REQUEST['router'], 'post', array('enctype'=>'multipart/form-data')); ?>
			<?php foreach($Info as $item): ?>
				<h4>Activate License for module <?php echo  $item->name;?></h4>
			<?php endforeach; ?>
			<input type="text" name="license" id="license" placeholder="Enter your license" /><br/>
			<input type="submit" name="submit" id="submit" Value="Activate" class="btn btn-primary btn-large" />
		<?php echo CHtml::endForm(); ?>
	</div>
	<?php endif; ?>
</div>
